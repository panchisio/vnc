package com.panchi.user.fotosgalery;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.MultiProcessor;
import com.google.android.gms.vision.Tracker;
import com.google.android.gms.vision.face.Face;
import com.google.android.gms.vision.face.FaceDetector;
import com.panchi.user.fotosgalery.Comunes.Permisos;
import com.panchi.user.fotosgalery.Modelos.Parametros;
import com.panchi.user.fotosgalery.Servicios.Comunes;
import com.panchi.user.fotosgalery.Servicios.Servicio;
import com.panchi.user.fotosgalery.camera.CameraSourcePreview;
import com.panchi.user.fotosgalery.camera.GraphicOverlay;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RecognitionActivity extends AppCompatActivity {
    private static final String TAG = "FaceTracker";

    private CameraSource mCameraSource = null;

    ProgressDialog loading;

    private CameraSourcePreview mPreview;
    private GraphicOverlay mGraphicOverlay;

    AsyncTask tarea;
    TextView contador;
    ImageView imv;

    Parametros parametros;
    Servicio mIpServicio;

    private final String CARPETA_RAIZ="pics";
    private final String RUTA_IMAGEN=CARPETA_RAIZ+"misFotos";

    String path;
    Button boton;


    private static final int RC_HANDLE_GMS = 9001;
    // permission request codes need to be < 256
    private static final int RC_HANDLE_CAMERA_PERM = 2;
    public static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 4883;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recognition);

        boton = (Button) findViewById(R.id.presionar);
        imv = (ImageView) findViewById(R.id.imv);

        parametros = new Parametros();




        mPreview = (CameraSourcePreview) findViewById(R.id.facePreview);
        mGraphicOverlay = (GraphicOverlay) findViewById(R.id.faceOverlay);

        contador = (TextView) findViewById(R.id.text_count);

        //Al iniciar pedimos los permisos correspondientes
        int rc = ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
        if (rc == PackageManager.PERMISSION_GRANTED) {
            Log.d("Permiso","Permiso Camara Ok"+" : "+rc);
            peticionPermisoAlmacenamiento();

        } else {
            peticionPermisoCamara();
            Log.d("Permiso","Permiso Camara No"+" : "+rc);
        }


        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mCameraSource.takePicture(null, new CameraSource.PictureCallback() {
                    @Override
                    public void onPictureTaken(byte[] bytes) {
                        Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                        imv.setImageBitmap(bmp);

                        bmp = Bitmap.createScaledBitmap(bmp, 640, 480, false);

                        ByteArrayOutputStream array=new ByteArrayOutputStream();
                        bmp.compress(Bitmap.CompressFormat.JPEG,50,array);
                        byte[] imagenByte=array.toByteArray();
                        String imagenString= Base64.encodeToString(imagenByte,Base64.NO_WRAP);
                        Log.d("Boton", "b64"+bmp.getWidth());

                    }
                });

            }
        });

    }



    private void createCameraSource() {
        Log.d("Reconocimiento", "Creamos la camara");

        Context context = getApplicationContext();
        FaceDetector detector = new FaceDetector.Builder(context)
                .setClassificationType(FaceDetector.ALL_CLASSIFICATIONS)
                .build();

        detector.setProcessor(
                new MultiProcessor.Builder<>(new GraphicFaceTrackerFactory())
                        .build());

        if (!detector.isOperational()) {
            // Note: The first time that an app using face API is installed on a device, GMS will
            // download a native library to the device in order to do detection.  Usually this
            // completes before the app is run for the first time.  But if that download has not yet
            // completed, then the above call will not detect any faces.
            //
            // isOperational() can be used to check if the required native library is currently
            // available.  The detector will automatically become operational once the library
            // download completes on device.
            Log.d("Reconocimiento", "Detector no implementado");
        }

        mCameraSource = new CameraSource.Builder(context, detector)
                .setRequestedPreviewSize(640, 480)//640 480
                .setFacing(CameraSource.CAMERA_FACING_FRONT)//seleccionamos la camara frente CAMERA_FACING_FRONT||atras CAMERA_FACING_BACK
                .setRequestedFps(30.0f)
                .build();
    }



    public void enviarDatos(String imagen){
        Log.d("Datos", "Llenando datos");

        parametros.setC_nombre("Panchi");
        parametros.setC_foto(imagen);

        mIpServicio = Comunes.EnviarDatos();
        mIpServicio.enviarDatos(parametros).enqueue(new Callback<Parametros>() {
            @Override
            public void onResponse(Call<Parametros> call, Response<Parametros> response) {
                if(response.code() == 200){
                    Log.d("Datos", "Respuesta si");
                    boton.setText("Response: "+response.code()+": img: "+response.body().getRespuesta());
                    loading.dismiss();
                }
            }

            @Override
            public void onFailure(Call<Parametros> call, Throwable t) {
                Log.d("Datos", "Respuesta No: "+t.getMessage());
                boton.setText(t.getMessage());
                loading.dismiss();

            }
        });
    }

    public class CargarDatos extends AsyncTask<Bitmap , Integer, String >{

        String imagenString;

        @Override
        protected String doInBackground(Bitmap... bitmaps) {

            ByteArrayOutputStream array=new ByteArrayOutputStream();
            bitmaps[0].compress(Bitmap.CompressFormat.JPEG,80,array);
            byte[] imagenByte=array.toByteArray();
            imagenString= Base64.encodeToString(imagenByte,Base64.NO_WRAP);

            return "Exito";
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s=="Exito"){
                enviarDatos(imagenString);
            }
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onCancelled(String s) {
            super.onCancelled(s);
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
        }
    }




    CameraSource.PictureCallback pictureCallback = new CameraSource.PictureCallback() {

        @Override
        public void onPictureTaken(byte[] bytes) {

            loading = ProgressDialog.show(RecognitionActivity.this, "Por favor espere...", "Consultando datos...", false, false);
            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes , 0, bytes .length);
            //imv.setImageBitmap(bitmap);
            bitmap = Bitmap.createScaledBitmap(bitmap, 1600, 1200, false);

            new CargarDatos().execute(bitmap);
            //converit la imagen en asynctask

            //String n = convertirImgString(bitmap);
            //enviarDatos(n);

        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("Reconocimiento", "Onresume");

        startCameraSource();
    }

    /**
     * Stops the camera.
     */
    @Override
    protected void onPause() {
        super.onPause();
        mPreview.stop();
        Log.d("Reconocimiento", "onPause");
    }

    /**
     * Releases the resources associated with the camera source, the associated detector, and the
     * rest of the processing pipeline.
     */
    @Override
    protected void onDestroy() {
        Log.d("Reconocimiento", "onDestroy");
        super.onDestroy();
        if (mCameraSource != null) {
            mCameraSource.release();
        }
    }

    private void peticionPermisoCamara() {

        final String[] permissions = new String[]{Manifest.permission.CAMERA};

        //La primera vez entra y verifica los permisos

        if (!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
            ActivityCompat.requestPermissions(this, permissions, Permisos.RC_HANDLE_CAMERA_PERM);
            return;
        }

        //A partir de la segunda ocacion Muestra un Snackbar solicitando los permisos

        //INICIO SKB
        final Activity thisActivity = this;

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivityCompat.requestPermissions(thisActivity, permissions, Permisos.RC_HANDLE_CAMERA_PERM);
            }
        };


        Snackbar.make(mGraphicOverlay, "Necesita conceder Permisos",
                Snackbar.LENGTH_INDEFINITE)
                .setAction("Ok", listener)
                .show();
        //FIN SKB
    }

    private void peticionPermisoAlmacenamiento() {

        final String[] permissions = new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE};

        //La primera vez entra y verifica los permisos

        if (!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            ActivityCompat.requestPermissions(this, permissions, Permisos.RC_WRITE_EXTERNAL_STORAGE_PERM);
            return;
        }

        //A partir de la segunda ocacion Muestra un Snackbar solicitando los permisos

        //INICIO SKB
        final Activity thisActivity = this;

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivityCompat.requestPermissions(thisActivity, permissions, Permisos.RC_WRITE_EXTERNAL_STORAGE_PERM);
            }
        };


        Snackbar.make(mGraphicOverlay, "Necesita conceder Permisos",
                Snackbar.LENGTH_INDEFINITE)
                .setAction("Ok", listener)
                .show();
        //FIN SKB
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        //Log.d("Permiso","Code: "+requestCode + grantResults[0]);

        switch(requestCode) {
            case Permisos.RC_HANDLE_CAMERA_PERM:
                //Log.d("Permiso","Code: "+requestCode + grantResults[0]);
                if(grantResults[0]== -1) {
                    Log.d("Permiso", "Negado: " + requestCode + grantResults[0]);
                    dialogoPermisoCancelado();
                }else{
                    Log.d("Permiso", "Permiso concedido: " + requestCode + grantResults[0]);
                    peticionPermisoAlmacenamiento();
                }
                break;
            case Permisos.RC_WRITE_EXTERNAL_STORAGE_PERM:

                if(grantResults[0]== -1) {
                    Log.d("Permiso", "Negado: " + requestCode + grantResults[0]);
                    dialogoPermisoCancelado();
                }else{
                    createCameraSource();
                    Log.d("Permiso", "Permiso concedido: " + requestCode + grantResults[0]);
                }

                break;
            default:

                break;
        }
    }

    private void dialogoPermisoCancelado(){
        DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                finish();
            }
        };

        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
        builder.setTitle("Permisos Necesarios")
                .setMessage("Es necesario conceda permiso, la aplicacion se cerrara hasta que otorge los permisos necesarios")
                .setPositiveButton("Ok", listener)
                .show();

    }

    public class Counter extends AsyncTask<Void, Integer, String>{
        @Override
        protected String doInBackground(Void... voids) {
            int count=0;
            for (count=0; count <= 3; count++) {
                try {
                    Thread.sleep(1000);
                    publishProgress(count);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            try{//I GET ERROR HERE
                mCameraSource.takePicture(null,pictureCallback);
            }catch (Exception ex){
                Toast.makeText(getApplicationContext(),"Error:"+ex.toString(),Toast.LENGTH_LONG).show();
            }
            contador.setText("");
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            contador.setText("Running..."+ values[0]);
        }
    }

    private void startCameraSource() {

        // check that the device has play services available.
        int code = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(
                getApplicationContext());
        if (code != ConnectionResult.SUCCESS) {
            Dialog dlg =
                    GoogleApiAvailability.getInstance().getErrorDialog(this, code, RC_HANDLE_GMS);
            dlg.show();
        }

        if (mCameraSource != null) {
            try {
                mPreview.start(mCameraSource, mGraphicOverlay);

            } catch (IOException e) {
                //Log.d("Reconocimiento", "error en camara"+e.getMessage());
                Log.e(TAG, "Unable to start camera source.", e);
                mCameraSource.release();
                mCameraSource = null;
            }
        }
    }

    private class GraphicFaceTrackerFactory implements MultiProcessor.Factory<Face> {
        @Override
        public Tracker<Face> create(Face face) {
            return new GraphicFaceTracker(mGraphicOverlay);
        }
    }

    /**
     * Face tracker for each detected individual. This maintains a face graphic within the app's
     * associated face overlay.
     */
    private class GraphicFaceTracker extends Tracker<Face> {
        private GraphicOverlay mOverlay;
        private FaceGraphic mFaceGraphic;



        GraphicFaceTracker(GraphicOverlay overlay) {
            mOverlay = overlay;
            mFaceGraphic = new FaceGraphic(overlay);
        }

        /**
         * Start tracking the detected face instance within the face overlay.
         */
        @Override
        public void onNewItem(int faceId, Face item) {

            mFaceGraphic.setId(faceId);
            Log.d("Reconocimiento", "onNew");

            //Ejecutamos el asynctask 5 segundos tome la foto la almacene y la suba

            tarea = new Counter().execute();


        }

        /**
         * Update the position/characteristics of the face within the overlay.
         */
        @Override
        public void onUpdate(FaceDetector.Detections<Face> detectionResults, Face face) {
            mOverlay.add(mFaceGraphic);
            mFaceGraphic.updateFace(face);

            if(detectionResults.detectorIsOperational()){
                //Log.d("Reconocimiento", "onUpdate: "+detectionResults.getDetectedItems().size()+" id: "+face.getId());
                //contador.setText(""+detectionResults.getDetectedItems().size());
            }
            //Log.d("Reconocimiento", "onUpdate: "+detectionResults.getDetectedItems().size());
        }

        /**
         * Hide the graphic when the corresponding face was not detected.  This can happen for
         * intermediate frames temporarily (e.g., if the face was momentarily blocked from
         * view).
         */
        @Override
        public void onMissing(FaceDetector.Detections<Face> detectionResults) {
            mOverlay.remove(mFaceGraphic);

            //Log.d("Reconocimiento", "onMissing: "+detectionResults.getDetectedItems().size());
            tarea.cancel(true);
            contador.setText("");


        }

        /**
         * Called when the face is assumed to be gone for good. Remove the graphic annotation from
         * the overlay.
         */
        @Override
        public void onDone() {

            mOverlay.remove(mFaceGraphic);
            //Log.d("Reconocimiento", "onDone: ");
            tarea.cancel(true);

        }
    }
}
