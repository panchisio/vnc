package com.panchi.user.fotosgalery;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.panchi.user.fotosgalery.Modelos.Parametros;
import com.panchi.user.fotosgalery.Servicios.Comunes;
import com.panchi.user.fotosgalery.Servicios.Servicio;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SendImage extends AppCompatActivity {

    Servicio mIpServicio;
    EditText nombres, apellidos, email, telefono, cedula, carrera, presentacion;
    ProgressDialog loading, loading_cv, loading_foto;
    ImageView _foto;
    Bitmap _foto_cv, _fotoUp;
    Button cv, guardar;
    TextView ruta_cv;
    private int VALOR_RETORNO = 1;
    ImageBase imageBase;
    String i;
    LinearLayout llcv;
    String path;
    String fotoUp, fotoBack;
    String yu, yu_back;


    private final String CARPETA_RAIZ="misImagenesPrueba/";
    private final String RUTA_IMAGEN=CARPETA_RAIZ+"misFotos";

    final int COD_SELECCIONA=10;
    final int COD_FOTO=20;
    Context context= this;

    Parametros parametros;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_image);

        parametros = new Parametros();

        imageBase =  new ImageBase();
        fotoUp=null;
        yu =null;

        nombres = (EditText) findViewById(R.id.txt_cv_nombre);
        apellidos = (EditText) findViewById(R.id.txt_cv_apellido);
        email = (EditText) findViewById(R.id.txt_cv_email);
        telefono = (EditText) findViewById(R.id.txt_cv_telefono);
        cedula = (EditText) findViewById(R.id.txt_cv_cedula);
        carrera = (EditText) findViewById(R.id.txt_cv_carrera);
        cv = (Button) findViewById(R.id.cargar_cv);
        ruta_cv = (TextView) findViewById(R.id.txt_ruta_cv);
        llcv = (LinearLayout) findViewById(R.id.ll_cv);
        _foto = (ImageView) findViewById(R.id.btn_mi_cv_photo);
        guardar = (Button) findViewById(R.id.btn_guardar_datos_personales);
        presentacion = (EditText) findViewById(R.id.txt_cv_presentacion);



        //new CargarDatos().execute(Integer.toString(_id));

        cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(Intent.createChooser(intent, "Choose File"), VALOR_RETORNO);
            }
        });



        guardar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(final View view) {

                ///convertir a pdf
                //final File dwldsPath = new File(Environment.getExternalStorageDirectory().toString()+"/Download/j.jpg");
                // byte[] pdfAsBytes = Base64.decode(yu, 0);
                //FileOutputStream os;
                //try {
                //    os = new FileOutputStream(dwldsPath, false);
                //    os.write(pdfAsBytes);
                //    os.flush();
                //    os.close();
                //} catch (java.io.IOException e) {
                //    e.printStackTrace();
                //}

                parametros.setC_nombre("Panchi");
                parametros.setC_foto(fotoUp);

                mIpServicio = Comunes.EnviarDatos();
                mIpServicio.enviarDatos(parametros).enqueue(new Callback<Parametros>() {
                    @Override
                    public void onResponse(Call<Parametros> call, Response<Parametros> response) {
                        if(response.code() == 200){
                            Log.d("Datos", "Respuesta si");
                        }
                    }

                    @Override
                    public void onFailure(Call<Parametros> call, Throwable t) {
                        Log.d("Datos", "Respuesta No: "+t.getMessage());

                    }
                });




            }
        });

        _foto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cargarImagen();
            }
        });


    }




    public class ActualizarEstudiante extends AsyncTask<Void, Integer, String>{

        public ActualizarEstudiante() {
            super();
        }

        @Override
        protected String doInBackground(Void... voids) {



            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onCancelled(String s) {
            super.onCancelled(s);
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
        }
    }

    public class ConverterImgToString extends AsyncTask<Void,Void,String>{
        public ConverterImgToString() {
            super();
        }

        @Override
        protected String doInBackground(Void... voids) {
            fotoUp = imageBase.convertirImgString(_fotoUp);
            Log.d("imagen","Base64"+fotoUp);
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            //presentacion.setText(fotoUp);
            loading_foto.dismiss();
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onCancelled(String s) {
            super.onCancelled(s);
            loading_foto.dismiss();
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
            loading_foto.dismiss();
        }
    }



    public class Converter64 extends AsyncTask<String, Void,String>{

        public Converter64() {
            super();
        }

        @Override
        protected String doInBackground(String... strings) {
            //i = imageBase.convertirPath(strings[0]);
            yu = imageBase.B64(strings[0]);
            Log.i("BASE",yu);

            return "Exito";
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();


        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s=="Exito"){
                llcv.setVisibility(View.VISIBLE);
                //presentacion.setText(i);
                loading_cv.dismiss();
            }
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onCancelled(String s) {
            super.onCancelled(s);
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
        }
    }


    private void cargarImagen() {

        final CharSequence[] opciones={"Tomar Foto","Cargar Imagen","Cancelar"};
        final AlertDialog.Builder alertOpciones=new AlertDialog.Builder(this);
        alertOpciones.setTitle("Seleccione una Opción");
        alertOpciones.setItems(opciones, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (opciones[i].equals("Tomar Foto")){
                    tomarFotografia();
                }else{
                    if (opciones[i].equals("Cargar Imagen")){
                        Intent intent=new Intent(Intent.ACTION_GET_CONTENT, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                        intent.setType("image/");
                        startActivityForResult(intent.createChooser(intent,"Seleccione la Aplicación"),COD_SELECCIONA);

                    }else{
                        dialogInterface.dismiss();
                    }
                }
            }
        });
        alertOpciones.show();

    }

    private void tomarFotografia() {
        File fileImagen=new File(Environment.getExternalStorageDirectory(),RUTA_IMAGEN);
        boolean isCreada=fileImagen.exists();
        String nombreImagen="";
        if(isCreada==false){
            isCreada=fileImagen.mkdirs();
        }

        if(isCreada==true){
            nombreImagen=(System.currentTimeMillis()/1000)+".jpg";
        }


        path=Environment.getExternalStorageDirectory()+File.separator+RUTA_IMAGEN+File.separator+nombreImagen;

        File imagen=new File(path);

        Intent intent=null;
        intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        ////
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.N)
        {
            String authorities=getApplicationContext().getPackageName()+".provider";
            Uri imageUri= FileProvider.getUriForFile(context,authorities,imagen);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        }else
        {
            intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(imagen));
        }
        startActivityForResult(intent,COD_FOTO);

        ////
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_CANCELED) {
            //Cancelado por el usuario
            llcv.setVisibility(View.GONE);
        }
        if ((resultCode == RESULT_OK) && (requestCode == VALOR_RETORNO )) {
            Uri uri = data.getData();
            String n = RealPathUtil.getRealPathFromURI_API19(this, uri);
            loading_cv = ProgressDialog.show(this, "Por favor espere...", "Cargando CV...", false, false);
            new Converter64().execute(n);
        }
        if (resultCode==RESULT_OK){

            switch (requestCode){
                case COD_SELECCIONA:
                    Uri miPath=data.getData();
                    Log.d("imagen","selecciona imagen");
                    //sendImage.setImageURI(miPath);
                    InputStream inputStream = null;
                    try {
                        inputStream = getApplicationContext().getContentResolver().openInputStream(miPath);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    _fotoUp = BitmapFactory.decodeStream(inputStream);
                    _foto.setImageBitmap(_fotoUp);
                    Log.d("imagen","Path: "+miPath);
                    loading_foto = ProgressDialog.show(this, "Por favor espere...", "Cargando Imagen...", false, false);
                    new ConverterImgToString().execute();
                    break;

                case COD_FOTO:
                    MediaScannerConnection.scanFile(this, new String[]{path}, null,
                            new MediaScannerConnection.OnScanCompletedListener() {
                                @Override
                                public void onScanCompleted(String path, Uri uri) {
                                    Log.i("Ruta de almacenamiento","Path: "+path);
                                }
                            });

                    _fotoUp= BitmapFactory.decodeFile(path);
                    _foto.setImageBitmap(_fotoUp);
                    loading_foto = ProgressDialog.show(this, "Por favor espere...", "Cargando Imagen...", false, false);
                    new ConverterImgToString().execute();

                    break;
            }


        }
    }




}
