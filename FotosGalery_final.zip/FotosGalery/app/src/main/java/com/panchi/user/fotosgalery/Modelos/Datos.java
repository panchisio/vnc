package com.panchi.user.fotosgalery.Modelos;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Datos {


    @SerializedName("nombre")
    @Expose
    private String nombre;

    @SerializedName("foto")
    @Expose
    private String foto;


    public Datos() {
    }

    public String getNombre() {

        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }
}
