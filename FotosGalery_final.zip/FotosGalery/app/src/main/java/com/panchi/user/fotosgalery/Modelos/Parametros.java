package com.panchi.user.fotosgalery.Modelos;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Parametros {

    @SerializedName("c_nombre")
    @Expose
    private String c_nombre;

    @SerializedName("c_foto")
    @Expose
    private String c_foto;

    @SerializedName("respuesta")
    @Expose
    private String respuesta;

    public Parametros() {
    }

    public String getC_nombre() {
        return c_nombre;
    }

    public void setC_nombre(String c_nombre) {
        this.c_nombre = c_nombre;
    }

    public String getC_foto() {
        return c_foto;
    }

    public void setC_foto(String c_foto) {
        this.c_foto = c_foto;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }
}
