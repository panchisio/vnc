package com.panchi.user.fotosgalery;


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import static android.support.constraint.Constraints.TAG;

public class ImageBase {

    public String convertirImgString(Bitmap bitmap) {

        ByteArrayOutputStream array=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,50,array);
        byte[] imagenByte=array.toByteArray();
        String imagenString= Base64.encodeToString(imagenByte,Base64.NO_WRAP);

        return imagenString;
    }

    public Bitmap convertirStringImage(String imageString){
        byte[] imageBytes;
        imageBytes = Base64.decode(imageString, Base64.DEFAULT);
        Bitmap decodedImage = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
        return decodedImage;
    }


    public String convertirPath(String path) {
        String base64 = "";
        try {
            File file = new File(path);
            byte[] buffer = new byte[(int) file.length() + 500];
            @SuppressWarnings("resource")
            int length = new FileInputStream(file).read(buffer);
            base64 = Base64.encodeToString(buffer, 0, length, Base64.DEFAULT);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return base64;
    }

    public String convertirFile(File path) {
        String base64 = "";
        try {
            //File file = new File(path);
            byte[] buffer = new byte[(int) path.length() + 100];
            @SuppressWarnings("resource")
            int length = new FileInputStream(path).read(buffer);
            base64 = Base64.encodeToString(buffer, 0, length,Base64.DEFAULT);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return base64;
    }

    public String encodeFile(){
        String testValue = "Hello, world!";
        byte[] encodeValue = Base64.encode(testValue.getBytes(), Base64.DEFAULT);
        //byte[] decodeValue = Base64.decode(encodeValue, Base64.DEFAULT);
        return encodeValue.toString();
    }

    private static String base64Encode(final byte[] input) {
        return Base64.encodeToString(input, Base64.DEFAULT);
    }

    public String B64(String path){
        String n="";
        File file = new File(path);
        int size = (int) file.length();
        byte[] bytes = new byte[size];
        try {
            int length = new FileInputStream(path).read(bytes);
            n = Base64.encodeToString(bytes, 0, length,Base64.DEFAULT);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return n;
    }









}
