package com.panchi.user.fotosgalery.Comunes;

public class Permisos {

    public static final int RC_HANDLE_CAMERA_PERM = 2498;
    public static final int RC_WRITE_EXTERNAL_STORAGE_PERM = 2499;
    public static final int RC_PHONE_PERM = 2450;


}
