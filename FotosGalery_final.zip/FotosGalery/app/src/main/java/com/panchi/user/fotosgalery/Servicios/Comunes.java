package com.panchi.user.fotosgalery.Servicios;


import com.panchi.user.fotosgalery.Modelos.RetrofitCliente;

public class Comunes {


    private static final String BASE_API = "http://panchisio.es/multiempresa/public/";

    public static Servicio EnviarDatos(){
        return RetrofitCliente.getClient(BASE_API).create(Servicio.class);
    }



}
