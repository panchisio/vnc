package com.panchi.user.fotosgalery.Servicios;

import com.panchi.user.fotosgalery.Modelos.Datos;
import com.panchi.user.fotosgalery.Modelos.Parametros;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface Servicio {



    @POST("imagen")
    Call<Parametros> enviarDatos(@Body Parametros datos);




}
